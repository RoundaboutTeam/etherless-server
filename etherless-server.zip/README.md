# etherless-server

Module for ethereum events listening and managing of calls to AWS lambda functions.

Run "node app.js" to run server.