function echo(word) {
  return word;
};
